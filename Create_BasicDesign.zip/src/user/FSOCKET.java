package user;

public class FSOCKET {
	public static final String NEWUSER_CODE = "newUser";
	public static final String HASH_CODE = "hash";
	public static final String LOGIN_CODE = "Login";
	public static final String FUNDING_CODE = "funding";
	public static final String CHARGE_CODE = "Charge";
	public static final String COMPENSATE_CODE = "compensate";
	public static final String QUIT_CODE = "quit";
}
