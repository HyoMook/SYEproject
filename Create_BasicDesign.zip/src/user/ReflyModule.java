package user;

public class ReflyModule {
	private int num;
	private int primaryKey;
	private String userID;
	private String replycontent;
	private String WRI_DTT;
	
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public int getPrimaryKey() {
		return primaryKey;
	}
	public void setPrimaryKey(int primaryKey) {
		this.primaryKey = primaryKey;
	}
	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID;
	}
	public String getReplycontent() {
		return replycontent;
	}
	public void setReplycontent(String replycontent) {
		this.replycontent = replycontent;
	}
	public String getWRI_DTT() {
		return WRI_DTT;
	}
	public void setWRI_DTT(String wRI_DTT) {
		WRI_DTT = wRI_DTT;
	}
}
