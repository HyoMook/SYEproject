package user;

public class VolunteerPlanModule {
	private int num;
	private String userid;
	private String vol_date;
	private String vol_time;
	private String palce;
	private String vol_goal;
	private String activity_content;
	private String vol_prepare;
	private String etc;
	
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getVol_date() {
		return vol_date;
	}
	public void setVol_date(String vol_date) {
		this.vol_date = vol_date;
	}
	public String getVol_time() {
		return vol_time;
	}
	public void setVol_time(String vol_time) {
		this.vol_time = vol_time;
	}
	public String getPalce() {
		return palce;
	}
	public void setPalce(String palce) {
		this.palce = palce;
	}
	public String getVol_goal() {
		return vol_goal;
	}
	public void setVol_goal(String vol_goal) {
		this.vol_goal = vol_goal;
	}
	public String getActivity_content() {
		return activity_content;
	}
	public void setActivity_content(String activity_content) {
		this.activity_content = activity_content;
	}
	public String getVol_prepare() {
		return vol_prepare;
	}
	public void setVol_prepare(String vol_prepare) {
		this.vol_prepare = vol_prepare;
	}
	public String getEtc() {
		return etc;
	}
	public void setEtc(String etc) {
		this.etc = etc;
	}
}
